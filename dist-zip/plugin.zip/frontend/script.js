let f;
const B = (o) => {
  f = o;
};
function D(o, e) {
  return f.graphql.createAssistantSession({
    input: {
      systemMessage: o,
      modelId: e
    }
  });
}
function q(o, e) {
  return f.graphql.sendAssistantMessage({
    sessionId: o,
    message: e
  });
}
function H(o) {
  return new Promise((e, t) => {
    const n = setInterval(() => {
      f.graphql.assistantSession({ id: o }).then((s) => {
        if (s.assistantSession.messages.length >= 3) {
          const a = s.assistantSession.messages[2].content;
          clearInterval(n), e(a);
        }
      }).catch((s) => {
        clearInterval(n), t(s);
      });
    }, 1e3);
  });
}
function S(o) {
  return f.graphql.deleteAssistantSession({
    id: o
  });
}
function $(o, e) {
  let t = null;
  return D(o, "gpt-3.5-turbo").then((n) => (t = n.createAssistantSession.session.id, q(t, e))).then(() => H(t)).then((n) => S(t).then(() => n)).catch((n) => t ? S(t).then(() => Promise.reject(n)) : Promise.reject(n));
}
function F() {
  const o = document.querySelectorAll('.c-tab[data-is-selected="true"]');
  return Array.from(o).map((t) => t.getAttribute("data-session-id"));
}
function U() {
  let o = window.location.hash;
  return o.includes("?custom-path=") && (o = o.split("?custom-path=")[1]), o;
}
function V(o, e) {
  const t = document.querySelector(".p-contextmenu-root-list"), n = document.createElement("li");
  n.id = `pv_id_1_${t.children.length}`, n.className = "p-menuitem", n.setAttribute("role", "menuitem"), n.setAttribute("aria-label", o), n.setAttribute("aria-level", "1"), n.setAttribute("aria-setsize", t.children.length + 1), n.setAttribute("aria-posinset", t.children.length), n.setAttribute("data-pc-section", "menuitem"), n.setAttribute("data-p-highlight", "false"), n.setAttribute("data-p-focused", "false"), n.innerHTML = `
        <div class="p-menuitem-content" data-pc-section="content">
            <div data-v-25e37fb9 class="c-context-menu__item">
                <div class="c-context-menu__content">${o}</div>
                <div class="c-context-menu__trailing-visual"></div>
            </div>
        </div>
    `, n.addEventListener("click", function() {
    e(), z();
  }), t.appendChild(n);
}
function z() {
  const o = document.querySelector(".p-contextmenu");
  o && (o.style.display = "none");
}
function G(o) {
  const e = o.split(`
`), t = e[0], n = e[1], s = e.join(`
`).split(`

`)[1];
  return t + `
` + n + `

` + (s || "");
}
async function W(o) {
  const e = (await f.graphql.replaySessionEntries({ id: o.toString() })).replaySession.activeEntry;
  if (console.log(e), e) {
    const t = e.request.id, n = (await f.graphql.request({ id: t })).request;
    if (n)
      return n.raw;
  }
}
function j(o) {
  return o.includes("operationName");
}
function K(o) {
  const t = /"operationName"\s*:\s*"([^"]+)"/.exec(o);
  return t && t[1] ? t[1] : "BUG!! No operationName found";
}
class X {
  log(e, t) {
  }
  info(e) {
    this.log("info", e);
  }
  error(e) {
    this.log("error", e);
  }
  warn(e) {
    this.log("warn", e);
  }
}
const x = new X();
class Q {
  constructor() {
    this.events = {};
  }
  registerEvent(e, t) {
    this.events[e] = t;
  }
  triggerEvent(e, t) {
    const n = this.events[e];
    n ? n.trigger(t) : console.error(`Event "${e}" not registered.`);
  }
  on(e, t) {
    const n = this.events[e];
    n ? n.addHandler(t) : console.error(`Event "${e}" not registered.`);
  }
  initEvents() {
    x.info(`Initializing ${Object.keys(this.events).length} custom events`);
    for (const e in this.events)
      this.events[e].init();
  }
}
class Z {
  constructor() {
    this.handlers = [];
  }
  addHandler(e) {
    this.handlers.push(e);
  }
  init() {
    const e = setInterval(() => {
      J() && (clearInterval(e), this.trigger());
    }, 25);
  }
  trigger() {
    this.handlers.forEach((e) => e());
  }
}
const J = () => document.querySelector(".c-content") !== null;
class Y {
  constructor() {
    this.handlers = [];
  }
  addHandler(e) {
    this.handlers.push(e);
  }
  init() {
    new MutationObserver((t) => {
      for (let n of t)
        n.type === "childList" && n.addedNodes.forEach((s) => {
          const a = s;
          s.nodeType === 1 && a.classList.contains("p-contextmenu") && this.trigger(a);
        });
    }).observe(document.body, { childList: !0, subtree: !0 });
  }
  trigger(e) {
    this.handlers.forEach((t) => t(e));
  }
}
class ee {
  constructor(e) {
    this.handlers = [], this.eventManager = e;
  }
  addHandler(e) {
    this.handlers.push(e);
  }
  init() {
    let e = window.location.href;
    const t = new MutationObserver(() => {
      var s;
      if (window.location.href !== e) {
        let a = new URL(window.location.href).hash, r = new URL(e).hash;
        e = window.location.href, a.includes("?custom-path=") && (a = a.split("?custom-path=")[1]), r.includes("?custom-path=") && (r = r.split("?custom-path=")[1]), (s = document.querySelector(".c-content")) == null || s.setAttribute("data-page", a), this.trigger({
          newUrl: a,
          oldUrl: r
        });
      }
    }), n = { subtree: !0, childList: !0 };
    t.observe(document, n);
  }
  trigger(e) {
    x.info(`Page updated: ${e.oldUrl} -> ${e.newUrl}`), e.newUrl.startsWith("#/settings/") && this.eventManager.triggerEvent(
      "onSettingsTabOpen",
      e.newUrl.replace("#/settings/", "")
    ), this.handlers.forEach((t) => t(e));
  }
}
class te {
  constructor() {
    this.handlers = [];
  }
  addHandler(e) {
    this.handlers.push(e);
  }
  init() {
  }
  trigger(e) {
    x.info(`Settings tab opened: ${e}`), this.handlers.forEach((t) => t(e));
  }
}
let E = null;
const ne = (o) => {
  E = o;
}, w = () => {
  if (!E)
    throw new Error("PluginData is not set yet!");
  return E;
}, I = async (o, e) => {
  const t = w();
  localStorage.setItem(`ebapi:settings:${t.manifestID}:${o}`, e);
}, C = (o) => {
  const e = w();
  return localStorage.getItem(`ebapi:settings:${e.manifestID}:${o}`);
}, se = () => localStorage.getItem(`ebapi:${w().manifestID}:welcomeToast`), T = () => {
  localStorage.removeItem(`ebapi:${w().manifestID}:welcomeToast`);
}, ae = async (o) => {
  localStorage.setItem(`ebapi:${w().manifestID}:welcomeToast`, JSON.stringify(o));
}, oe = `
.v-toast--fade-in {
    animation: fadeIn 0.15s ease-in-out forwards;
}
@keyframes fadeIn {
    from {
        opacity: 0;
    }
    to {
        opacity: 1;
    }
}
.v-toast--fade-out {
    animation: fadeOut 0.15s ease-in-out forwards;
}
@keyframes fadeOut {
    from {
        opacity: 1;
    }
    to {
        opacity: 0;
    }
}`, re = (o, e, t) => {
  const n = document.createElement("div");
  n.classList.add("v-toast"), n.classList.add(`v-toast--${t}`);
  const s = document.createElement("div");
  s.setAttribute("role", "alert"), s.classList.add("v-toast__item"), s.classList.add(`v-toast__item--${e}`), s.classList.add(`v-toast__item--${t}`), n.appendChild(s);
  const a = document.createElement("div");
  a.classList.add("v-toast__icon"), s.appendChild(a);
  const r = document.createElement("p");
  return r.classList.add("v-toast__text"), r.textContent = o, s.appendChild(r), n.classList.add("v-toast--fade-in"), n;
}, ie = (o) => {
  let { message: e, type: t, position: n, duration: s } = o;
  n || (n = "bottom"), t || (t = "success"), s || (s = 3e3);
  let a = document.querySelector(
    `.v-toast--${n}`
  );
  a || (a = document.createElement("div"), a.classList.add("v-toast"), a.classList.add(`v-toast--${n}`), document.body.appendChild(a));
  const r = re(e, t, n);
  a.appendChild(r), setTimeout(() => {
    r.classList.add("v-toast--fade-out"), setTimeout(() => {
      r.remove();
    }, 150);
  }, s - 150);
};
class ce {
  constructor(e) {
    this.showToast = (t) => {
      ie(t);
    }, this.setWelcomeMessage = (t) => {
      ae(t);
    }, this.evenBetterAPI = e, this.evenBetterAPI.helpers.loadCSS({ id: "eb-toast", cssText: oe });
  }
}
class de {
  constructor() {
    this.handlers = [], this.commandObserver = null, this.selectedCommand = null;
  }
  addHandler(e) {
    this.handlers.push(e);
  }
  init() {
    const e = (s) => {
      this.commandObserver = new MutationObserver((a) => {
        const r = t();
        r !== this.selectedCommand && (this.selectedCommand = r);
      }), this.commandObserver.observe(s, {
        attributes: !0,
        subtree: !0
      });
    }, t = () => document.querySelector("[command-item][aria-selected='true']");
    new MutationObserver((s) => {
      for (let a of s)
        a.type === "childList" && (a.addedNodes.forEach((r) => {
          const i = r;
          r.nodeType === 1 && i.hasAttribute("command-theme") && e(i);
        }), a.removedNodes.forEach((r) => {
          const i = r;
          if (r.nodeType === 1 && i.hasAttribute("command-theme")) {
            if (!this.selectedCommand)
              return;
            const c = this.selectedCommand.getAttribute("data-value");
            c && this.trigger(c), this.commandObserver && (this.commandObserver.disconnect(), this.commandObserver = null);
          }
        }));
    }).observe(document.body, { childList: !0, subtree: !0 });
  }
  trigger(e) {
    this.handlers.forEach((t) => t(e));
  }
}
const le = "2.0.0";
let y = null;
const ue = (o) => {
  y = o;
}, pe = () => {
  if (!y)
    throw new Error("CaidoAPI is not set yet!");
  return y;
}, me = `
.eb-checkbox__input {
    cursor: pointer;
    -webkit-appearance: none;
    appearance: none;
    width: 1.15em;
    height: 1.15em;
    border: .1em solid grey;
    border-radius: 4px;
    display: inline-grid;
    place-content: center;
    margin: 0;
}
.eb-checkbox__input:checked:before {
    transform: scale(1);
}
.eb-checkbox__input:before {
    content: "";
    transform: scale(0);
    width: .65em;
    height: .65em;
    border-radius: 2px;
    box-shadow: inset 1em 1em var(--c-fg-secondary);
}
.eb-button__label {
    display: inline-flex;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}
`, he = (o) => {
  o.helpers.loadCSS({ id: "checkbox", cssText: me });
  const e = document.createElement("div");
  e.classList.add("eb-button__label");
  const t = document.createElement("div");
  t.classList.add("eb-checkbox");
  const n = document.createElement("div");
  n.classList.add("formkit-outer"), n.dataset.family = "box", n.dataset.type = "checkbox", n.dataset.complete = "true";
  const s = document.createElement("label");
  s.classList.add("formkit-wrapper", "eb-checkbox__wrapper"), s.dataset.checked = "true";
  const a = document.createElement("span");
  a.classList.add("formkit-inner", "eb-checkbox__inner");
  const r = document.createElement("input");
  r.classList.add("formkit-input", "eb-checkbox__input"), r.type = "checkbox";
  const i = document.createElement("span");
  return i.classList.add("formkit-decorator"), i.setAttribute("aria-hidden", "true"), a.appendChild(r), a.appendChild(i), s.appendChild(a), n.appendChild(s), t.appendChild(n), e.appendChild(t), e;
}, be = `
.eb-text-input__inner {
    gap: var(--c-space-1); 
    flex: 1; 
    display: flex; 
    align-items: center; 
    padding-left: var(--c-space-2); 
    padding-right: var(--c-space-2); 
    box-sizing: border-box; 
    border: var(--c-border-width-1) solid var(--c-border-default); 
    border-radius: var(--c-border-radius-2); 
    color: var(--c-fg-default); 
    background-color: var(--c-bg-default); 
    min-height: var(--c-space-10);
}
.eb-text-input__inner:focus-within {
    border: var(--c-border-width-2) solid var(--c-border-secondary);
}
.eb-text-input__inner textarea {
  padding-top: var(--c-space-2);
}
`;
function fe(o, e, t, n = !1, s) {
  o.helpers.loadCSS({ id: "eb-text-input", cssText: be });
  const a = document.createElement("div");
  a.classList.add("formkit-outer", "c-text-input__outer"), a.setAttribute("style", `width: ${e};`);
  const r = document.createElement("div");
  r.classList.add("formkit-wrapper"), r.style.display = "flex";
  const i = document.createElement("div");
  i.classList.add("formkit-inner", "eb-text-input__inner");
  const c = document.createElement("div");
  c.classList.add("c-text-input__prefix"), c.setAttribute(
    "style",
    "align-self: center; color: var(--c-fg-subtle);"
  );
  const l = document.createElement("i");
  l.classList.add("c-icon", "fas"), s && l.classList.add(s);
  const d = document.createElement("input");
  if (t && t != "" && d.setAttribute("placeholder", t), d.setAttribute("spellcheck", "false"), d.classList.add("formkit-input", "c-text-input__input"), d.setAttribute("type", "text"), d.setAttribute(
    "style",
    "width: 100%; background: transparent; border: 0; outline: 0; color: inherit; box-sizing: border-box; line-height: inherit;"
  ), s && c.appendChild(l), i.appendChild(c), i.appendChild(d), n) {
    const u = document.createElement("button");
    u.innerHTML = '<i class="fas fa-copy"></i>', u.setAttribute(
      "style",
      "background: transparent; border: 0; outline: 0; cursor: pointer; padding: 0; margin-left: 10px;"
    ), u.addEventListener("click", () => {
      navigator.clipboard.writeText(d.value), o.toast.showToast({
        message: "Copied to clipboard",
        position: "bottom",
        type: "info",
        duration: 1e3
      });
    }), i.appendChild(u);
  }
  return r.appendChild(i), a.appendChild(r), a;
}
function ve(o, e) {
  const t = document.createElement("div");
  t.classList.add("c-menu-bar"), t.style.width = "100%";
  const n = document.createElement("div");
  n.classList.add("p-menubar", "p-component"), n.setAttribute("data-pc-name", "menubar"), n.setAttribute("data-pc-section", "root");
  const s = document.createElement("div");
  s.classList.add("p-menubar-start"), s.setAttribute("data-pc-section", "start");
  const a = document.createElement("div");
  a.classList.add("c-settings__title"), a.style.padding = "0 var(--c-space-4)", a.style.fontWeight = "700", a.textContent = e.title, s.appendChild(a);
  const r = document.createElement("ul");
  r.classList.add("p-menubar-root-list");
  const i = e.items.map((d) => d.url);
  e.items.forEach((d) => {
    const u = document.createElement("li");
    u.classList.add("p-menuitem"), u.setAttribute("role", "menuitem"), u.style.margin = "0";
    const b = document.createElement("div");
    b.classList.add("p-menuitem-content"), b.setAttribute("data-pc-section", "content");
    const m = document.createElement("div");
    m.classList.add("c-settings__item"), m.setAttribute("data-is-active", "true"), m.addEventListener("click", () => {
      n.classList.remove("p-menubar-mobile-active");
    });
    const p = document.createElement("a");
    p.setAttribute("href", d.url), p.setAttribute("draggable", "false"), p.draggable = !1, p.classList.add("p-menuitem-link"), d.url === location.hash && (p.style.backgroundColor = "rgba(255,255,255,.04)", p.style.borderRadius = "var(--c-border-radius-2)");
    let h = null;
    if (o.eventManager.on("onPageOpen", (v) => {
      if (d.sidebarItemName)
        if (i.includes(v.newUrl)) {
          const _ = document.querySelectorAll(".c-sidebar-item");
          if (_) {
            const k = Array.from(_).filter(
              (O) => O.textContent === d.sidebarItemName
            );
            k.length >= 1 && (h = k[0], h.setAttribute("data-is-selected", "true"), h.setAttribute("data-is-active", "true"));
          }
        } else
          h && (h.removeAttribute("data-is-selected"), h.removeAttribute("data-is-active"), h = null);
      v.newUrl === d.url ? (d.onOpen && d.onOpen(), p.style.backgroundColor = "rgba(255,255,255,.04)", p.style.borderRadius = "var(--c-border-radius-2)") : (p.style.backgroundColor = "", p.style.borderRadius = "");
    }), d.icon) {
      const v = document.createElement("i");
      v.classList.add("c-icon", "fas", d.icon), v.style.marginRight = "var(--c-space-2)", p.appendChild(v);
    }
    const A = document.createElement("span");
    A.textContent = d.title, p.appendChild(A), m.appendChild(p), b.appendChild(m), u.appendChild(b), r.appendChild(u);
  });
  const c = document.createElement("a");
  c.setAttribute("role", "button"), c.setAttribute("tabindex", "0"), c.classList.add("p-menubar-button"), c.setAttribute("aria-haspopup", "true"), c.setAttribute("aria-expanded", "false"), c.setAttribute("aria-label", "Navigation"), c.setAttribute("data-pc-section", "button"), c.setAttribute("aria-controls", "pv_id_3"), c.innerHTML = '<svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg" class="p-icon" aria-hidden="true" data-pc-section="menubuttonicon"><path fill-rule="evenodd" clip-rule="evenodd" d="M13.3226 3.6129H0.677419C0.497757 3.6129 0.325452 3.54152 0.198411 3.41448C0.0713707 3.28744 0 3.11514 0 2.93548C0 2.75581 0.0713707 2.58351 0.198411 2.45647C0.325452 2.32943 0.497757 2.25806 0.677419 2.25806H13.3226C13.5022 2.25806 13.6745 2.32943 13.8016 2.45647C13.9286 2.58351 14 2.75581 14 2.93548C14 3.11514 13.9286 3.28744 13.8016 3.41448C13.6745 3.54152 13.5022 3.6129 13.3226 3.6129ZM13.3226 7.67741H0.677419C0.497757 7.67741 0.325452 7.60604 0.198411 7.479C0.0713707 7.35196 0 7.17965 0 6.99999C0 6.82033 0.0713707 6.64802 0.198411 6.52098C0.325452 6.39394 0.497757 6.32257 0.677419 6.32257H13.3226C13.5022 6.32257 13.6745 6.39394 13.8016 6.52098C13.9286 6.64802 14 6.82033 14 6.99999C14 7.17965 13.9286 7.35196 13.8016 7.479C13.6745 7.60604 13.5022 7.67741 13.3226 7.67741ZM0.677419 11.7419H13.3226C13.5022 11.7419 13.6745 11.6706 13.8016 11.5435C13.9286 11.4165 14 11.2442 14 11.0645C14 10.8848 13.9286 10.7125 13.8016 10.5855C13.6745 10.4585 13.5022 10.3871 13.3226 10.3871H0.677419C0.497757 10.3871 0.325452 10.4585 0.198411 10.5855C0.0713707 10.7125 0 10.8848 0 11.0645C0 11.2442 0.0713707 11.4165 0.198411 11.5435C0.325452 11.6706 0.497757 11.7419 0.677419 11.7419Z" fill="currentColor"></path></svg>', c.addEventListener("click", () => {
    n.classList.toggle("p-menubar-mobile-active"), r.style.zIndex = n.classList.contains("p-menubar-mobile-active") ? "1200" : "";
  }), window.addEventListener("resize", () => {
    window.innerWidth < 955 ? n.classList.add("p-menubar-mobile") : (n.classList.remove("p-menubar-mobile"), n.classList.remove("p-menubar-mobile-active"));
  }), window.dispatchEvent(new Event("resize"));
  const l = document.createElement("div");
  return l.classList.add("p-menubar-end"), l.setAttribute("data-pc-section", "end"), l.style.display = "flex", l.style.gap = ".5em", l.style.alignItems = "center", e.customButtons && e.customButtons.forEach((d) => {
    l.appendChild(d);
  }), n.appendChild(s), n.appendChild(c), n.appendChild(r), n.appendChild(l), t.appendChild(n), t;
}
const ge = `
.eb-select {
    background-image: url(data:image/svg+xml;charset=US-ASCII,%3Csvg%20viewBox%3D%220%20-4.5%2020%2020%22%20version%3D%221.1%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20xmlns%3Axlink%3D%22http%3A%2F%2Fwww.w3.org%2F1999%2Fxlink%22%20fill%3D%22%23ffffff%22%3E%3Cg%20id%3D%22SVGRepo_bgCarrier%22%20stroke-width%3D%220%22%3E%3C%2Fg%3E%3Cg%20id%3D%22SVGRepo_tracerCarrier%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%3E%3C%2Fg%3E%3Cg%20id%3D%22SVGRepo_iconCarrier%22%3E%20%3Ctitle%3Earrow_down%20%5B%23ffffff%5D%3C%2Ftitle%3E%20%3Cdesc%3ECreated%20with%20Sketch.%3C%2Fdesc%3E%20%3Cdefs%3E%20%3C%2Fdefs%3E%20%3Cg%20id%3D%22Page-1%22%20stroke%3D%22none%22%20stroke-width%3D%221%22%20fill%3D%22none%22%20fill-rule%3D%22evenodd%22%3E%20%3Cg%20id%3D%22Dribbble-Light-Preview%22%20transform%3D%22translate%28-220.000000%2C%20-6684.000000%29%22%20fill%3D%22%23ffffff%22%3E%20%3Cg%20id%3D%22icons%22%20transform%3D%22translate%2856.000000%2C%20160.000000%29%22%3E%20%3Cpath%20d%3D%22M164.292308%2C6524.36583%20L164.292308%2C6524.36583%20C163.902564%2C6524.77071%20163.902564%2C6525.42619%20164.292308%2C6525.83004%20L172.555873%2C6534.39267%20C173.33636%2C6535.20244%20174.602528%2C6535.20244%20175.383014%2C6534.39267%20L183.70754%2C6525.76791%20C184.093286%2C6525.36716%20184.098283%2C6524.71997%20183.717533%2C6524.31405%20C183.328789%2C6523.89985%20182.68821%2C6523.89467%20182.29347%2C6524.30266%20L174.676479%2C6532.19636%20C174.285736%2C6532.60124%20173.653152%2C6532.60124%20173.262409%2C6532.19636%20L165.705379%2C6524.36583%20C165.315635%2C6523.96094%20164.683051%2C6523.96094%20164.292308%2C6524.36583%22%20id%3D%22arrow_down-%5B%23ffffff%5D%22%3E%20%3C%2Fpath%3E%20%3C%2Fg%3E%20%3C%2Fg%3E%20%3C%2Fg%3E%20%3C%2Fg%3E%3C%2Fsvg%3E);
    background-repeat: no-repeat;
    background-position: right 0.7rem top 50%;
    background-size: 0.65rem auto;
    width: 100%;
    height: var(--c-space-10);
    border-radius: var(--c-border-radius-2) 0px 0px var(--c-border-radius-2) !important;
    border: var(--c-border-width-1) solid var(--c-border-default);
    background-color: var(--c-bg-default);
    color: var(--c-fg-default);
    -webkit-appearance: none;
    -moz-appearance: none;
    appearance: none;
    padding: 0 0.5em;
}
`;
function Ce(o, e) {
  o.helpers.loadCSS({ id: "eb-select", cssText: ge });
  const t = document.createElement("select");
  return t.classList.add("eb-select"), e.forEach((n) => {
    const s = document.createElement("option");
    s.value = n.value, s.textContent = n.label, t.appendChild(s);
  }), t;
}
function we(o, ...e) {
  return o.reduce((t, n, s) => {
    let a = n + (e[s] !== void 0 ? e[s] : "");
    return t + a.replace(/\s+/g, " ").trim();
  }, "");
}
const Ee = () => we`
      <table role="table" class="p-datatable-table" data-pc-section="table">
        <thead class="p-datatable-thead" role="rowgroup" data-pc-section="thead" style="position: sticky;">
          <tr role="row" data-pc-section="headerrow">
          </tr>
        </thead>
        <tbody class="p-datatable-tbody" role="rowgroup" data-pc-section="tbody">
        </tbody>
      </table>
    `.trim(), ye = (o, e) => new L(e);
class L {
  constructor(e) {
    this.config = e, this.rows = [], this.tableElement = document.createElement("div"), this.tableElement.className = "p-datatable p-datatable-responsive-scroll p-datatable-striped p-datatable-sm", this.tableElement.style.overflow = "auto", this.tableElement.style.width = "100%", this.tableElement.innerHTML = Ee(), this.tableBody = this.tableElement.querySelector(
      ".p-datatable-tbody"
    );
    const t = this.tableElement.querySelector("table");
    t.style.width = "100%", t.style.tableLayout = "fixed";
    const n = this.tableElement.querySelector(
      "[data-pc-section=headerrow]"
    );
    if (!n)
      throw new Error("Column row not found");
    this.config.columns.forEach((s) => {
      const a = document.createElement("th");
      a.className = "p-column-header", a.setAttribute("role", "columnheader"), a.setAttribute("data-pc-section", "headercell"), a.setAttribute("data-p-resizable-column", "false"), a.setAttribute("data-p-filter-column", "false"), a.setAttribute("data-p-reorderable-column", "false"), a.setAttribute("first", "0");
      const r = document.createElement("div");
      r.className = "p-column-header-content", r.setAttribute("data-pc-section", "headercontent");
      const i = document.createElement("span");
      i.className = "p-column-title", i.setAttribute("data-pc-section", "headertitle"), i.textContent = s.name, r.appendChild(i), a.appendChild(r), s.width && (a.style.width = s.width), n.appendChild(a);
    });
  }
  filterRows(e) {
    let t = 0;
    this.rows.forEach((n) => {
      const s = n.htmlElement, a = n.cells;
      let r = !1;
      a.forEach((i) => {
        var c;
        typeof i.value == "string" ? i.value.toLowerCase().includes(e.toLowerCase()) && (r = !0) : (c = i.value.textContent) != null && c.toLowerCase().includes(e.toLowerCase()) && (r = !0);
      }), r ? (s.style.removeProperty("display"), s.classList.remove("p-row-even", "p-row-odd"), s.classList.add(
        t % 2 === 0 ? "p-row-even" : "p-row-odd"
      ), t++) : (s.style.display = "none", s.removeAttribute("data-is-even"));
    });
  }
  clearRows() {
    this.rows.forEach((e) => {
      e.htmlElement.remove();
    }), this.rows = [];
  }
  addRow(e, t) {
    const n = (this.tableBody.children.length + 1) % 2 !== 0, s = document.createElement("tr");
    s.className = `p-row-${n ? "even" : "odd"}`, s.setAttribute("tabindex", "-1"), s.setAttribute("role", "row"), s.setAttribute("data-pc-section", "bodyrow"), s.setAttribute("data-p-index", "0"), s.setAttribute("data-p-selectable-row", "false"), s.setAttribute("draggable", "false"), e.forEach((a) => {
      var c;
      const r = (c = this.config.columns.find(
        (l) => l.name === a.columnName
      )) == null ? void 0 : c.width, i = document.createElement("td");
      i.setAttribute("role", "cell"), i.style.whiteSpace = "nowrap", i.style.overflow = "hidden", i.setAttribute("data-pc-section", "bodycell"), i.setAttribute("data-pc-name", "bodycell"), i.setAttribute("data-p-selection-column", "false"), i.setAttribute("data-p-cell-editing", "false"), r && (i.style.width = r), typeof a.value == "string" ? i.textContent = a.value : i.appendChild(a.value), s.appendChild(i);
    }), t && s.addEventListener("click", t), this.tableBody.appendChild(s), this.rows.push({
      htmlElement: s,
      cells: e
    });
  }
  getHTMLElement() {
    return this.tableElement;
  }
  static createTable(e) {
    return new L(e);
  }
}
class xe {
  constructor(e) {
    this.apiInstance = e;
  }
  createTable(e) {
    return ye(this.apiInstance, e);
  }
  createNavigationBar(e) {
    return ve(this.apiInstance, e);
  }
  createCheckbox() {
    return he(this.apiInstance);
  }
  createTextInput(e, t, n = !1, s) {
    return fe(this.apiInstance, e, t, n, s);
  }
  createSelectInput(e) {
    return Ce(this.apiInstance, e);
  }
}
let R = [];
const Le = (o, e) => {
  var d;
  const t = document.createElement("div");
  t.classList.add("custom");
  const n = document.createElement("div");
  n.setAttribute("command-root", ""), t.appendChild(n);
  const s = document.createElement("div");
  s.setAttribute("command-dialog", ""), n.appendChild(s);
  const a = document.createElement("div");
  a.setAttribute("command-dialog-mask", ""), a.style.display = "flex", a.style.justifyContent = "center", a.style.alignItems = "center", a.addEventListener("click", () => {
    t.remove();
  }), s.appendChild(a);
  const r = document.createElement("div");
  r.setAttribute("command-dialog-wrapper", ""), r.style.minWidth = "600px", r.style.padding = "1em", r.style.margin = "0", a.appendChild(r);
  const i = document.createElement("div");
  i.setAttribute("command-dialog-body", ""), i.style.display = "flex", i.style.gap = "0.5em", r.addEventListener("click", (u) => {
    u.stopPropagation();
  }), r.appendChild(i);
  const c = o.components.createTextInput(
    "100%",
    e.promptPlaceholder
  );
  c.style.zIndex = "100", c.addEventListener("click", (u) => {
    u.stopPropagation();
  }), i.appendChild(c);
  const l = pe().ui.button({
    label: "Submit",
    variant: "primary"
  });
  l.addEventListener("click", () => {
    const u = c.querySelector("input");
    e.onPrompt(u.value), t.remove();
  }), i.appendChild(l), document.body.appendChild(t), (d = c.querySelector("input")) == null || d.focus(), c.addEventListener("keydown", (u) => {
    u.key === "Enter" && l.click(), u.key === "Escape" && t.remove();
  });
}, Ae = (o, e, t, n) => {
  R.push({
    commandName: e,
    promptPlaceholder: t,
    onPrompt: n
  });
};
class _e {
  constructor(e) {
    this.apiInstance = e, this.apiInstance.eventManager.on("onCommandRun", (t) => {
      const n = R.find(
        (s) => s.commandName === t
      );
      n && Le(this.apiInstance, n);
    });
  }
  createPromptCommand(e, t, n) {
    Ae(this.apiInstance, e, t, n);
  }
}
const ke = `
  .evenbetter-modal {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.5);
    display: flex;
    justify-content: center;
    align-items: center;
    z-index: 99999;
  }
  
  .evenbetter-modal__content {
    background-color: var(--c-bg-default);
    padding: 1rem;
    border-radius: 5px;
    width: 50%;
    max-width: 500px;
  }
  
  .evenbetter-modal__content-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1rem;
  }
  
  .evenbetter-modal__content-header-title {
    font-size: 1.1rem;
    margin: 0;
  }
  
  .evenbetter-modal__content-body {
    margin-bottom: 1rem;
  }
  
  .evenbetter-modal__content-body-text {
    font-size: 0.9rem;
    color: var(--c-fg-subtle);
    word-break: break-word;
    user-select: text !important;
    -webkit-user-select: text !important;
  
    white-space: break-spaces;
    overflow: auto;
    max-height: 40em;
  }
  
  .evenbetter-modal__content-body a {
    color: var(--c-fg-default);
  }
  
  .evenbetter-modal__content-body-close {
    background-color: var(--c-bg-subtle);
    border: 1px solid var(--c-header-cell-border);
    color: #fff;
    padding: 0.5rem;
    width: 100%;
    margin-top: 0.5rem;
    cursor: pointer;
    transition: 0.2s ease background-color;
  }
  
  .evenbetter-modal__content-body-close:hover {
    background-color: var(--c-bg-default);
  }
`, Se = ({
  modalAPI: o,
  title: e,
  content: t
}) => {
  const n = document.createElement("div");
  n.classList.add("evenbetter-modal");
  const s = document.createElement("div");
  s.classList.add("evenbetter-modal__content");
  const a = document.createElement("div");
  a.classList.add("evenbetter-modal__content-header");
  const r = document.createElement("h2");
  r.classList.add("evenbetter-modal__content-header-title"), r.textContent = e, a.appendChild(r);
  const i = document.createElement("div");
  i.classList.add("evenbetter-modal__content-body");
  const c = document.createElement("p");
  c.classList.add("evenbetter-modal__content-body-text"), typeof t == "string" ? c.innerHTML = t : t instanceof HTMLElement && c.appendChild(t);
  const l = document.createElement("button");
  return l.classList.add("evenbetter-modal__content-body-close"), l.textContent = "Close", l.addEventListener("click", o.closeModal), i.appendChild(c), i.appendChild(l), s.appendChild(a), s.appendChild(i), n.appendChild(s), n.setAttribute("data-modal-title", e), n;
}, Ie = () => document.querySelector(".evenbetter-modal") !== null;
class Te {
  constructor(e) {
    this.evenBetterAPI = e, this.evenBetterAPI.helpers.loadCSS({
      id: "evenbetterapi-modal",
      cssText: ke.toString()
    }), document.addEventListener("keydown", (t) => {
      t.key === "Escape" && this.closeModal();
    });
  }
  openModal({
    title: e,
    content: t
  }) {
    Ie() && this.closeModal();
    const n = Se({ modalAPI: this, title: e, content: t });
    document.body.appendChild(n);
  }
  closeModal() {
    const e = document.querySelector(".evenbetter-modal");
    e == null || e.remove();
  }
}
const M = () => typeof __TAURI_INVOKE__ < "u", P = async (o, e) => await __TAURI_INVOKE__(o, e), N = /* @__PURE__ */ new Set();
class Me {
  constructor() {
    this.downloadFile = async (e, t) => {
      if (M())
        return P("download", { filename: e, data: t });
      {
        const n = new Blob([t], { type: "text/plain" }), s = URL.createObjectURL(n), a = document.createElement("a");
        a.href = s, a.download = e, a.click();
      }
    }, this.openInBrowser = (e) => {
      M() ? P("open_in_browser", { url: e }) : window.open(e, "_blank");
    }, this.loadCSS = ({ id: e, cssText: t }) => {
      if (N.has(e) || document.querySelector(`#${e}`))
        return;
      const n = document.createElement("style");
      n.id = e, n.textContent = t, n.classList.add("evenbetterapi-css-module"), document.head.appendChild(n), N.add(e);
    };
  }
}
var g = /* @__PURE__ */ ((o) => (o.TEXT = "text", o.NUMBER = "number", o.CHECKBOX = "checkbox", o.SELECT = "select", o))(g || {});
class Pe {
  constructor(e, t) {
    this.evenBetterAPI = e, this.title = t.title, this.description = t.description, this.inputGroups = t.inputGroups, this.initDefaults();
  }
  async initDefaults() {
    for (const [e, t] of this.inputGroups.entries())
      for (const [n, s] of t.inputs.entries())
        s.defaultValue && !C(s.id) && await I(s.id, s.defaultValue);
  }
  className(e) {
    return `eb-settings-page__${e}`;
  }
  render() {
    const e = document.createElement("div");
    e.classList.add(this.className("container"));
    const t = document.createElement("div");
    t.classList.add(this.className("header"));
    const n = document.createElement("h1");
    n.textContent = this.title, n.classList.add(this.className("title")), t.appendChild(n);
    const s = document.createElement("p");
    s.textContent = this.description, s.classList.add(this.className("description")), t.appendChild(s), e.appendChild(t);
    const a = document.createElement("div");
    return a.classList.add(this.className("groups")), this.inputGroups.forEach((r) => {
      const i = document.createElement("div");
      i.classList.add(this.className("group")), r.width && (r.width.toLowerCase() == "fill-space" ? i.style.flex = "1" : i.style.width = r.width);
      const c = document.createElement("div");
      c.classList.add(this.className("group-header"));
      const l = document.createElement("div");
      l.textContent = r.groupName, l.classList.add(this.className("group-name"));
      const d = document.createElement("p");
      d.textContent = r.groupDescription, d.classList.add(this.className("group-description")), c.appendChild(l), c.appendChild(d), i.appendChild(c);
      const u = document.createElement("div");
      u.classList.add(this.className("group-inputs")), r.inputs.forEach((b) => {
        if (r.separateWithLine) {
          const p = document.createElement("hr");
          p.classList.add(this.className("line")), u.appendChild(p);
        }
        const m = this.createInputElement(b, (p) => {
          I(b.id, p);
        });
        u.appendChild(m);
      }), i.appendChild(u), a.appendChild(i);
    }), e.appendChild(a), e;
  }
  createInputElement(e, t) {
    const n = document.createElement("div");
    n.classList.add(this.className("input-wrapper")), e.type == g.CHECKBOX && n.classList.add(this.className("checkbox-wrapper"));
    const s = document.createElement("label");
    e.labelAsHTML ? s.innerHTML = e.label : s.textContent = e.label, s.setAttribute("for", e.id), n.appendChild(s);
    let a;
    switch (e.type) {
      case g.TEXT:
        a = this.evenBetterAPI.components.createTextInput(
          "100%",
          e.placeholder
        );
        const r = a.querySelector(
          "input"
        ), i = C(e.id);
        i ? r.value = i : r.value = e.defaultValue, t && r.addEventListener("input", (h) => {
          t(r.value);
        });
        break;
      case g.NUMBER:
        a = this.evenBetterAPI.components.createTextInput(
          "100%",
          e.placeholder
        ), a.querySelector("input").type = "number";
        const c = a.querySelector(
          "input"
        ), l = C(e.id);
        l ? c.value = l : c.value = e.defaultValue, t && c.addEventListener("input", (h) => {
          t(c.value);
        });
        break;
      case g.CHECKBOX:
        a = this.evenBetterAPI.components.createCheckbox();
        const d = a.querySelector(
          "input"
        ), u = C(e.id);
        u ? d.checked = u == "true" : d.checked = e.defaultValue == "true", t && d.addEventListener("change", (h) => {
          t(d.checked.toString());
        });
        break;
      case g.SELECT:
        const b = e.options;
        a = this.evenBetterAPI.components.createSelectInput(b);
        const m = a, p = C(e.id);
        p ? m.value = p : m.value = e.defaultValue, t && m.addEventListener("change", (h) => {
          t(m.value);
        });
        break;
      default:
        throw new Error(`Invalid input type: ${e.type}`);
    }
    return n.appendChild(a), n;
  }
}
class Ne {
  constructor(e) {
    this.apiInstance = e;
  }
  createSettingsPage(e) {
    return new Pe(this.apiInstance, e);
  }
}
class Re {
  constructor(e, t) {
    ue(e), ne(t), this.eventManager = new Q();
    const n = new Z(), s = new te(), a = new ee(this.eventManager), r = new Y(), i = new de();
    this.eventManager.registerEvent("onCaidoLoad", n), this.eventManager.registerEvent("onSettingsTabOpen", s), this.eventManager.registerEvent("onPageOpen", a), this.eventManager.registerEvent("onContextMenuOpen", r), this.eventManager.registerEvent("onCommandRun", i), this.eventManager.on("onCaidoLoad", () => {
      this.eventManager.triggerEvent("onPageOpen", {
        newUrl: location.hash,
        oldUrl: ""
      });
      const c = se();
      if (c) {
        try {
          this.toast.showToast(JSON.parse(c));
        } catch (l) {
          console.error(l), T();
        }
        T();
      }
    }), this.eventManager.initEvents(), this.helpers = new Me(), this.promptCommands = new _e(this), this.modal = new Te(this), this.toast = new ce(this), this.components = new xe(this), this.templates = new Ne(this), this.version = le;
  }
}
const Oe = "Given the user's HTTP request, provide a short name for the request one-five words max. Be descriptive and specific.", Be = async (o) => {
  const e = await W(o), t = G(e), n = t.split(`

`)[1];
  if (j(n)) {
    const s = K(n);
    f.graphql.renameReplaySession({
      id: o,
      name: `GraphQL: ${s}`
    });
    return;
  }
  return await $(Oe, t);
}, De = (o) => {
  const e = new Re(o, {
    manifestID: "ai-rename",
    name: "AI Replay Rename"
  });
  B(o), e.eventManager.on("onContextMenuOpen", (t) => {
    U() === "#/replay" && V("Generate Replay Name", async () => {
      F().map(async (s) => {
        const a = await Be(s);
        o.graphql.renameReplaySession({
          id: s,
          name: a
        });
      });
    });
  });
};
export {
  De as init
};
